const CONFIG = {
  pageWidth: 816,
  pageHeight: 1154,
  contentTop: 42,
  footerReserve: 112,
  assetRoot: 'assets/'
};

const SYSTEM_ORDER = ['RuralFinance', 'RuralTransportes', 'SiloVirtual'];

const app = document.getElementById('app');

async function loadData(){
  const response = await fetch('dados/informativo.json', {cache:'no-store'});
  if(!response.ok) throw new Error(`Não foi possível carregar dados/informativo.json (${response.status}).`);
  return response.json();
}

function el(tag, className, text){
  const node = document.createElement(tag);
  if(className) node.className = className;
  if(text !== undefined) node.textContent = text;
  return node;
}

function asset(path){
  if(!path) return '';
  return CONFIG.assetRoot + path.replace(/^assets\//,'');
}

function img(src, className, alt=''){
  const node = document.createElement('img');
  node.src = asset(src);
  node.className = className || '';
  node.alt = alt;
  return node;
}

function dateLabel(value){
  if(!value) return '';
  const [y,m,d] = value.split('-').map(Number);
  const dt = new Date(y,m-1,d || 1);
  return new Intl.DateTimeFormat('pt-BR',{month:'long',year:'numeric'}).format(dt).replace(/^./,c=>c.toUpperCase());
}

function makeFooter(pageNumber,totalPages){
  const footer = el('div','internal-footer');
  const brand = el('div','footer-brand');
  brand.appendChild(img('logo-ruralhub.png',''));
  const line = el('div','vline');
  const tag = el('div','tag','GESTÃO COMPLETA\nPARA O SEU AGRO');
  tag.style.whiteSpace='pre-line';
  brand.append(line,tag);
  footer.appendChild(brand);
  const pn = el('div','page-no');
  pn.appendChild(el('div','',`Pág. ${pageNumber} de ${totalPages}`));
  pn.appendChild(el('div','page-line'));
  footer.appendChild(pn);
  return footer;
}

function makeHeader(data){
  const header=el('div','internal-header');
  header.appendChild(el('div','internal-title','Informativo de modificações - ruralhub'));
  const date=el('div','internal-date');
  date.appendChild(img('capa/cover_calendar.png',''));
  date.appendChild(el('span','',dateLabel(data.data)));
  header.appendChild(date);
  header.appendChild(el('div','header-rule'));
  return header;
}

function makePage(data, kind){
  const page=el('section',`page internal ${kind||''}`);
  page.dataset.kind=kind||'';
  page.appendChild(makeHeader(data));
  const body=el('div','internal-body');
  page.appendChild(body);
  return {page,body};
}

function makeCover(data){
  const page=el('section','page cover');
  page.appendChild(img('capa/foto-lavoura.png','cover-photo','Lavoura ao pôr do sol'));
  page.appendChild(img('capa/moldura-verde.png','cover-frame',''));
  const content=el('div','cover-content');
  const date=el('div','cover-date');
  date.appendChild(img('capa/cover_calendar.png',''));
  date.appendChild(el('span','',dateLabel(data.data)));
  content.appendChild(date);
  content.appendChild(el('h1','',data.capa?.titulo || 'Informativo de modificações'));
  content.appendChild(img('logo-ruralhub.png','cover-logo','RuralHub'));
  content.appendChild(el('div','cover-rule'));
  content.appendChild(el('p','cover-intro',data.capa?.descricao || ''));
  const list=el('div','cover-highlights');
  for(const item of (data.capa?.destaques||[])){
    const row=el('div','highlight');
    row.appendChild(img(item.icone,'',item.texto));
    row.appendChild(el('span','',item.texto));
    list.appendChild(row);
  }
  content.appendChild(list);
  page.appendChild(content);
  page.appendChild(img('capa/cover_tagline.png','cover-tagline','Tecnologia que impulsiona o Agronegócio'));
  const footer=el('div','cover-footer');
  const brand=el('div','footer-brand');
  brand.appendChild(img('logo-ruralhub.png',''));
  brand.appendChild(el('div','vline'));
  const tag=el('div','tag','GESTÃO COMPLETA\nPARA O SEU AGRO'); tag.style.whiteSpace='pre-line';
  brand.appendChild(tag);
  footer.appendChild(brand);
  const pn=el('div','page-no'); pn.appendChild(el('div','',`Pág. 1 de TOTAL`)); pn.appendChild(el('div','page-line')); footer.appendChild(pn);
  page.appendChild(footer);
  return page;
}

function makeMainHeading(){
  const wrap=el('div','main-heading');
  const icon=el('div','icon-box');
  // Icon from the original document's warning illustration, reconstructed as a CSS symbol for portability.
  const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
  svg.setAttribute('viewBox','0 0 100 100'); svg.classList.add('warning-svg');
  svg.innerHTML='<path d="M50 7 94 86c3 6-2 10-8 10H14c-6 0-9-5-6-10L43 7c2-4 5-4 7 0Z" fill="none" stroke="#00547D" stroke-width="6"/><path d="M50 31v30" stroke="#00547D" stroke-width="7" stroke-linecap="round"/><circle cx="50" cy="73" r="4" fill="#00547D"/>';
  icon.appendChild(svg);
  const title=el('div','title-box','PRINCIPAIS NOVIDADES');
  wrap.append(icon,title); return wrap;
}

function makeMainTable(items){
  const table=el('table','main-table');
  table.innerHTML='<thead><tr><th>Novidade</th><th>Sistema / Plataforma</th></tr></thead>';
  const tbody=document.createElement('tbody');
  for(const item of items){
    const tr=el('tr','main-row');
    const td1=document.createElement('td'); const nov=el('div','main-nov');
    if(item.icone) nov.appendChild(img(`icones/${item.icone}`,'',item.novidade));
    nov.appendChild(el('span','',item.novidade)); td1.appendChild(nov);
    const td2=el('td','',item.sistemaPlataforma);
    tr.append(td1,td2); tbody.appendChild(tr);
  }
  table.appendChild(tbody); return table;
}

function buildMainPage(data){
  const {page,body}=makePage(data,'main-page');
  body.appendChild(makeMainHeading());
  body.appendChild(makeMainTable(data.principaisNovidades||[]));
  return page;
}

function makeSystemHeading(system){
  const blue=system.cor==='azul';
  const wrap=el('div',`system-heading ${blue?'blue':''}`);
  const ib=el('div','icon-box'); ib.appendChild(img(system.icone,'',system.nome));
  const tb=el('div','title-box'); tb.appendChild(el('h2','',system.titulo)); tb.appendChild(el('p','',system.subtitulo));
  wrap.append(ib,tb); return wrap;
}

function makeDataTableHeader(){
  const table=el('table','data-table');
  table.innerHTML='<thead><tr><th>Tela</th><th>Novidade</th><th>O que mudou?</th></tr></thead><tbody></tbody>';
  return table;
}

function rowFor(item){
  const tr=el('tr','data-row');
  const td1=document.createElement('td'); const screen=el('div','data-screen');
  if(item.icone) screen.appendChild(img(`icones/${item.icone}`,'',item.tela));
  screen.appendChild(el('span','',item.tela)); td1.appendChild(screen);
  tr.appendChild(td1);
  tr.appendChild(el('td','novelty',item.novidade));
  tr.appendChild(el('td','description',item.descricao));
  return tr;
}

function makeSystemPage(data,system,items,pageNo,totalPages,closing){
  const {page,body}=makePage(data,'system-page');
  body.appendChild(makeSystemHeading(system));
  const table=makeDataTableHeader();
  const tbody=table.querySelector('tbody');
  items.forEach(i=>tbody.appendChild(rowFor(i)));
  body.appendChild(table);
  if(closing) body.appendChild(makeClosing(data));
  return page;
}

function makeClosing(data){
  const box=el('div','closing');
  const copy=el('div','closing-copy');
  copy.appendChild(el('h2','',data.rodape?.titulo || 'Juntos cultivamos o futuro!'));
  copy.appendChild(el('p','',data.rodape?.descricao || ''));
  box.appendChild(copy); box.appendChild(img('capa/muda.png','', 'Muda'));
  return box;
}

function allSystemItems(data){
  return SYSTEM_ORDER.flatMap(id => {
    const sys=data.sistemas?.[id];
    return sys?.solicitacoes?.map(x=>({...x,_system:id}))||[];
  });
}

function paginateSystems(data, systemId, items){
  const system=data.sistemas[systemId];
  const pages=[];
  let index=0;
  while(index<items.length){
    const {page,body}=makePage(data,'system-page');
    body.appendChild(makeSystemHeading(system));
    const table=makeDataTableHeader();
    const tbody=table.querySelector('tbody');
    body.appendChild(table);
    // Add rows one by one. The page has a fixed printable height, so DOM measurements decide the split.
    while(index<items.length){
      const row=rowFor(items[index]);
      tbody.appendChild(row);
      if(body.scrollHeight > body.clientHeight || page.scrollHeight > page.clientHeight){
        tbody.removeChild(row);
        break;
      }
      index++;
    }
    // Safety: an unusually tall single row still needs to be emitted.
    if(index===0){ tbody.appendChild(rowFor(items[index])); index++; }
    pages.push(page);
  }
  return pages;
}

function buildDocument(data){
  app.innerHTML='';
  const pages=[];
  pages.push(makeCover(data));
  if((data.principaisNovidades||[]).length) pages.push(buildMainPage(data));
  for(const id of SYSTEM_ORDER){
    const sys=data.sistemas?.[id];
    if(!sys || !sys.solicitacoes?.length) continue;
    pages.push(...paginateSystems(data,id,sys.solicitacoes));
  }
  // O bloco final tenta ocupar a última página disponível. Se não houver espaço,
  // recebe uma página própria para não repetir artificialmente uma tabela do sistema.
  const last=pages[pages.length-1];
  const lastBody=last.querySelector('.internal-body');
  if(lastBody && last.classList.contains('system-page')){
    const closing=makeClosing(data);
    lastBody.appendChild(closing);
    if(last.scrollHeight > last.clientHeight){
      lastBody.removeChild(closing);
      const p=makePage(data,'closing-page');
      p.body.appendChild(closing);
      pages.push(p.page);
    }
  }
  // Remove empty trailing page only if no content.
  const total=pages.length;
  pages.forEach((p,i)=>{
    p.querySelectorAll('.page-no').forEach(n=>{
      const first=n.firstElementChild;
      if(first) first.textContent=`Pág. ${i+1} de ${total}`;
    });
    const coverNo=p.querySelector('.cover-footer .page-no');
    if(coverNo && coverNo.firstElementChild) coverNo.firstElementChild.textContent=`Pág. ${i+1} de ${total}`;
    app.appendChild(p);
  });
  const toolbar=el('div','toolbar');
  const btn=el('button','', 'Imprimir / PDF'); btn.onclick=()=>window.print(); toolbar.appendChild(btn); document.body.appendChild(toolbar);
}

loadData().then(buildDocument).catch(err=>{
  console.error(err); app.innerHTML=`<div class="loading"><strong>Erro ao carregar o informativo.</strong><br>${err.message}<br><br>Abra o projeto por um servidor local (por exemplo: <code>python -m http.server</code>).</div>`;
});
